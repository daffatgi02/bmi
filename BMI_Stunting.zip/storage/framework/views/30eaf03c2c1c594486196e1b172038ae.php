<div class="d-flex">
    <a href="<?php echo e(route('danaks.edit', ['danak' => $danak->id])); ?>" class="btn btn-primary btn-sm me-2 shadow">
        <i class="bi-pencil-square"></i>
    </a>

    <div>
        <form action="<?php echo e(route('danaks.destroy', ['danak' => $danak->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-danger btn-sm me-2 btn-delete shadow">
                <i class="bi-trash"></i>
            </button>
        </form>

    </div>
</div>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/actiondanak.blade.php ENDPATH**/ ?>