<?php $__env->startSection('content'); ?>
    <div class="loading-overlay">
        <div class="spinner-container">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <label>Loading</label>
        </div>
    </div>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="home-section mb-5">
        <div class="mt-2 p-4">
            <?php if(count($dbulanans) > 0): ?>
                <button id="printButton" class="d-none">Cetak Halaman</button>
                <p class="text-center fs-3 fw-bold mb-3">
                    Data Bulanan - <?php echo e($dbulanans[0]->danaks->nama_anak); ?>

                </p>
            <?php endif; ?>
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header fw-bold">
                        <button class="accordion-button " type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <label for="" class="fw-bold">
                               1. Kurva Berat Badan Menurut Panjang/Tinggi Badan
                            </label>
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                        <div class="p-4 pe-none">
                            <?php echo $chart3->container(); ?>

                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header fw-bold">
                        <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <label for="" class="fw-bold">
                               2. Kurva Panjang/Tinggi Badan Menurut Umur (Bulan)
                            </label>
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="p-4 pe-none">
                            <?php echo $chart2->container(); ?>

                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header fw-bold">
                        <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <label for="" class="fw-bold">
                              3. Kurva Berat Badan Menurut Umur (Bulan)
                            </label>
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="p-4 pe-none">
                            <?php echo $chart->container(); ?>

                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header fw-bold">
                        <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            <label for="" class="fw-bold">
                              4. Kurva Linkar Kepala Menurut Umur (Bulan)
                            </label>
                        </button>
                    </h2>
                    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="p-4 pe-none">
                            <?php echo $chart4->container(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row p-lg-4 p-0">
                <div class="col-12 mt-4 mb-5 table-container">
                    <!-- Tambahkan elemen pembatas untuk memulai halaman baru -->
                    <div class="page-break"></div>

                    <table class="table table-striped table-hover table-bordered datatable shadow" id="example"
                        style="width: 100%">
                        <thead>
                            <tr>
                                <th id="th" class="text-center align-middle w-25">Nama</th>
                                <th id="th" class="text-center align-middle w-25">Umur Periksa</th>
                                <th id="th" class="text-center align-middle">Berat Badan</th>
                                <th id="th" class="text-center align-middle">Tinggi Badan</th>
                                <th id="th" class="text-center align-middle">Lingkar Lengan</th>
                                <th id="th" class="text-center align-middle">Lingkar Kepala</th>
                                <th id="th" class="text-center align-middle w-25">Status</th>
                                <th id="th" class="text-center align-middle w-25">Tanggal Periksa</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider">
                            <?php $__currentLoopData = $dbulanans->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($data->danaks->nama_anak); ?></td>
                                    <td class="text-center">
                                        <?php echo e($data->umur_tahun); ?> Tahun
                                        <?php echo e($data->umur_bulan); ?> Bulan
                                    </td>
                                    <td class="text-center"><?php echo e($data->bb_anak); ?> kg</td>
                                    <td class="text-center"><?php echo e($data->tb_anak); ?> cm</td>
                                    <td class="text-center"><?php echo e($data->ll_anak); ?> cm</td>
                                    <td class="text-center"><?php echo e($data->lk_anak); ?> cm</td>
                                    <td class="text-center fw-bold"
                                        style="color: <?php echo e($data->st_anak === 'Normal' ? 'mediumseagreen' : ($data->st_anak === 'Gizi Buruk' ? 'red' : ($data->st_anak === 'Gizi Kurang' ? 'darkorange' : ($data->st_anak === 'Kelebihan Berat Badan' ? 'darkblue' : 'black')))); ?>">
                                        <?php echo e($data->st_anak); ?>

                                    </td>

                                    <td class="text-center"><?php echo e($data->created_at->format('Y-m-d')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Menampilkan overlay saat halaman dimuat
            document.querySelector('.loading-overlay').style.display = 'flex';

            // Sembunyikan overlay setelah 2 detik setelah semua konten dimuat
            window.addEventListener('load', function() {
                setTimeout(function() {
                    document.querySelector('.loading-overlay').style.display = 'none';
                }, 2500); // 2 detik (dalam milidetik)
            });
        });
    </script>
    

    <script src="<?php echo e($chart->cdn()); ?>"></script>
    <?php echo e($chart->script()); ?>

    <script src="<?php echo e($chart2->cdn()); ?>"></script>
    <?php echo e($chart2->script()); ?>

    <script src="<?php echo e($chart3->cdn()); ?>"></script>
    <?php echo e($chart3->script()); ?>

    <script src="<?php echo e($chart4->cdn()); ?>"></script>
    <?php echo e($chart4->script()); ?>



    <script>
        // Fungsi ini dipanggil setelah delay 1.5 detik
        new DataTable('#example', {
            responsive: true,
            lengthChange: false, // Menghilangkan opsi page length
            paging: false, // Menghilangkan paging (halaman)
            searching: false,
            pageLength: -1 // Menghilangkan kotak pencarian
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/detailbulanan.blade.php ENDPATH**/ ?>