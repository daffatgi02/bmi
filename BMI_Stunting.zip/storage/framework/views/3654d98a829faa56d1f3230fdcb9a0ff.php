<?php $__env->startSection('content'); ?>
<div class="loading-overlay">
    <div class="spinner-container">
        <div class="spinner-border text-success" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <label>Loading</label>
    </div>
</div>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="home-section mb-5">
        <div class="mt-2 p-4">
            <?php if(count($dbulanans) > 0): ?>
                <button id="printButton" class="d-none">Cetak Halaman</button>
                <p class="text-center fs-3 fw-bold mb-3">
                    Data Bulanan - <?php echo e($dbulanans[0]->danaks->nama_anak); ?>

                </p>
            <?php endif; ?>
            <div class="row d-flex">
                <div class="col-12 pe-4 chart-container">
                    <?php echo $chart->container(); ?>

                </div>
                <div class="col-12 mt-4 mb-5 table-container">
                    <!-- Tambahkan elemen pembatas untuk memulai halaman baru -->
                    <div class="page-break"></div>

                    <table class="table table-striped table-hover table-bordered datatable shadow" id="example"
                        style="width: 100%">
                        <thead>
                            <tr>
                                <th id="th" class="text-center">Nama</th>
                                <th id="th" class="text-center">Umur Periksa</th>
                                <th id="th" class="text-center">Berat Badan</th>
                                <th id="th" class="text-center">Tinggi Badan</th>
                                <th id="th" class="text-center">Lingkar Lengan</th>
                                <th id="th" class="text-center">Lingkar Kepala</th>
                                <th id="th" class="text-center">Status</th>
                                <th id="th" class="text-center">Tanggal Periksa</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider">
                            <?php $__currentLoopData = $dbulanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->danaks->nama_anak); ?></td>
                                    <td class="text-center"><?php echo e($data->umur_periksa); ?></td>
                                    <td class="text-center"><?php echo e($data->bb_anak); ?></td>
                                    <td class="text-center"><?php echo e($data->tb_anak); ?></td>
                                    <td class="text-center"><?php echo e($data->ll_anak); ?></td>
                                    <td class="text-center"><?php echo e($data->lk_anak); ?></td>
                                    <td class="text-center fw-bold"
                                        style="color: <?php echo e($data->st_anak === 'Normal' ? 'mediumseagreen' : ($data->st_anak === 'Gizi Buruk' ? 'red' : ($data->st_anak === 'Gizi Kurang' ? 'darkorange' : ($data->st_anak === 'Kelebihan Berat Badan' ? 'darkblue' : 'black')))); ?>">
                                        <?php echo e($data->st_anak); ?>

                                    </td>

                                    <td class="text-center"><?php echo e($data->created_at->format('Y-m-d')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Menampilkan overlay saat halaman dimuat
            document.querySelector('.loading-overlay').style.display = 'flex';

            // Sembunyikan overlay setelah 2 detik setelah semua konten dimuat
            window.addEventListener('load', function() {
                setTimeout(function() {
                    document.querySelector('.loading-overlay').style.display = 'none';
                }, 1000); // 2 detik (dalam milidetik)
            });
        });
    </script>
    
    <script src="<?php echo e($chart->cdn()); ?>"></script>
    <?php echo e($chart->script()); ?>

    <script>
        // Fungsi ini dipanggil setelah delay 1.5 detik
        new DataTable('#example', {
            responsive: true,
            lengthChange: false, // Menghilangkan opsi page length
            paging: false, // Menghilangkan paging (halaman)
            searching: false,
            pageLength: -1 // Menghilangkan kotak pencarian
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/detailbulanan.blade.php ENDPATH**/ ?>