<div class="d-flex">
    <div>
        <form action="<?php echo e(route('dbulanans.destroy', ['dbulanan' => $dantrian->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-success-cp btn-sm me-2 btn-delete shadow">
                <i class="bi bi-check2-circle fs-6"></i>
            </button>
        </form>
    </div>
</div>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/actionantrian.blade.php ENDPATH**/ ?>