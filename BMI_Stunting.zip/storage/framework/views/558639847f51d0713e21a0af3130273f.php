<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 mt-md-4 mt-5 pt-md-0 pt-5">
                <div class="card shadow mb-3">
                    <div class="card-header" id="calc-stunting">
                        <h2>Login</h2>
                    </div>
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12 col-lg-6 d-md-block d-none mt-3">
                                        <img class="img-fluid" src="<?php echo e(Vite::asset('resources/images/LogoMojokerto.png')); ?>"
                                            alt="logo"style="width: auto;">
                                    </div>
                                    <div class="col-md-12 col-lg-6 col-12">
                                        <div class="row mb-3">
                                            <label for="email" class="col-form-label fw-bold">Email</label>
                                            <div class="col-md-12 ">
                                                <input id="email" type="email"
                                                    class="form-control shadow <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border border-dark-subtle"
                                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                                    autofocus>
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>Maaf, Perikasa Kembali Email dan Password</strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="password" class=" col-form-label fw-bold">Password</label>

                                            <div class="col-md-12">
                                                <input id="myPassword" type="password"
                                                    class="form-control shadow <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border border-dark-subtle"
                                                    name="password" required autocomplete="current-password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-12">
                                                <div class="form-check">
                                                    <input class="form-check-input border border-secondary shadow"
                                                        type="checkbox" name="remember" id="remember"
                                                        <?php echo e(old('remember') ? 'checked' : ''); ?> onclick="myFunction()">

                                                    <label class="form-check-label" for="remember">
                                                        Tampilkan Password
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-0 d-flex justify-content-center">
                                            <div class="col-md-8 d-grid col">
                                                <button type="submit" class="btn btn-logreg fw-bold shadow">
                                                    Masuk
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="mt-5 mb-5 ms-3">
                            <h4>
                                Anda Sudah Login, Silahkan
                                <a href="<?php echo e(route('bidans.index')); ?>" class="btn btn-primary ms-2 mt-2"> Masuk </a>
                            </h4>
                        </div>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
    </div>
    <script>
        function myFunction() {
            var x = document.getElementById("myPassword");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/auth/login.blade.php ENDPATH**/ ?>