<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mt-md-5 mt-5 pt-md-0 pt-5">
                <h1>Akun Sudah Teregistrasi</h1>
                <div class="card">
                    <div class="card-header fw-bold" id="calc-stunting">Informasi</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        Akun <b><?php echo e(Auth::user()->name); ?></b> sudah Teregistrasi sebagai!
                        <br>
                        <a class="btn btn-logreg fw-bold mt-5" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            Masuk
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/home.blade.php ENDPATH**/ ?>