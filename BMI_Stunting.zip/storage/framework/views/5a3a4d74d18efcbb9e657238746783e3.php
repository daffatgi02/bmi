<?php $__env->startSection('content'); ?>
    <div class="loading-overlay">
        <div class="spinner-container">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <label>Loading</label>
        </div>
    </div>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="home-section">
        <div class="content">
            <div class="container mt-3 pt-3">
                <div class="row ">
                    <h1 class="fw-bold h mb-4">Dashboard</h1>

                    
                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                        <div class="card shadow rounded-2" id="card-dash"
                            style="width: 18rem; max-width:18rem; height: 15rem; max-height:15rem;">
                            <h5 class="card-header fw-bold"> <i class='bx bx-user'></i> Total Anak</h5>
                            <div class="card-body rounded-bottom-2" id="card-body-dash">
                                <h6 class="card-title">Pada Posyandu Kelurahan Japan</h6>
                                <div class="d-flex flex-row">
                                    <h1 class="me-2 fw-bold"><?php echo e($danaks->count()); ?></h1>
                                    <p class="fw-bold">
                                        Laki-laki: <?php echo e($danaks->where('jk', 'L')->count()); ?> <br>
                                        Perempuan: <?php echo e($danaks->where('jk', 'P')->count()); ?>

                                    </p>
                                </div>
                                <a href="<?php echo e(route('danaks.index')); ?>" class="btn btn-light fw-bold"
                                    id="btn-detail-dashboard">
                                    <i class="bi bi-info-circle me-1"></i> Detail
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                        <div class="card shadow rounded-2" id="card-dash"
                            style="width: 18rem; max-width:18rem; height: 15rem; max-height:15rem;">
                            <h5 class="card-header fw-bold"><i class='bx bx-building-house'></i> Total Posyandu</h5>
                            <div class="card-body rounded-bottom-2" id="card-body-dash">
                                <h6 class="card-title">Pada Posyandu Kelurahan Japan</h6>
                                <div class="d-flex flex-row">
                                    <h1 class="fw-bold me-2"><?php echo e($dposyandus->count()); ?></h1>
                                    <p class="mt-2 fw-bold">
                                        Posyandu
                                    </p>
                                </div>
                                <a href="<?php echo e(route('dposyandus.index')); ?>" class="btn btn-light fw-bold"
                                    id="btn-detail-dashboard">
                                    <i class="bi bi-info-circle me-1"></i> Detail
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                        <div class="card shadow rounded-2" id="card-dash"
                            style="width: 18rem; max-width:18rem; height: 15rem; max-height:15rem;">
                            <h5 class="card-header fw-bold"><i class='bx bx-table'></i> Total Pendataan</h5>
                            <div class="card-body rounded-bottom-2" id="card-body-dash">
                                <h6 class="card-title">Pada Posyandu Kelurahan Japan</h6>
                                <div class="d-flex flex-row">
                                    <div class="d-flex flex-column me-4">
                                        <h1 class="me-2 fw-bold"><?php echo e($dbulans->count()); ?></h1>
                                        <a href="<?php echo e(route('dbulanans.index')); ?>" class="btn btn-light fw-bold"
                                            id="btn-detail-dashboard">
                                            <i class="bi bi-info-circle me-1"></i> Detail
                                        </a>
                                    </div>

                                    <div class="d-flex flex-row">
                                        <p class="fw-bold">
                                            <span class="badge text me-1" style="background-color:mediumseagreen"> &ensp;
                                            </span> <?php echo e($dbulans->where('st_anak', 'Normal')->count()); ?> <br>
                                            <span class="badge text me-1" style="background-color:darkorange"> &ensp;
                                            </span> <?php echo e($dbulans->where('st_anak', 'Gizi Kurang')->count()); ?> <br>
                                            <span class="badge text me-1" style="background-color:red"> &ensp; </span>
                                            <?php echo e($dbulans->where('st_anak', 'Gizi Buruk')->count()); ?> <br>

                                        </p>
                                    </div>
                                    <div class="d-flex flex-row ms-2">
                                        <p class="fw-bold">
                                            <span class="badge text me-1" style="background-color:darkblue"> &ensp; </span>
                                            <?php echo e($dbulans->where('st_anak', 'Kelebihan Berat Badan')->count()); ?> <br>
                                            <span class="badge text me-1" style="background-color:rgb(2, 2, 35)"> &ensp;
                                            </span> <?php echo e($dbulans->where('st_anak', 'Obesitas')->count()); ?>

                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                        <div class="card shadow rounded-2" id="card-dash"
                            style="width: 18rem; max-width:18rem; height: 15rem; max-height:15rem;">
                            <h5 class="card-header fw-bold"><i class='bx bx-walk'></i>Total Antrian</h5>
                            <div class="card-body rounded-bottom-2" id="card-body-dash">
                                <h6 class="card-title">Pada Posyandu Kelurahan Japan</h6>
                                <div class="d-flex flex-row">
                                    <h1 class="me-2 fw-bold"><?php echo e($dantrians->count()); ?></h1>
                                    <p class="mt-2 fw-bold">
                                        Antrian
                                    </p>
                                </div>
                                <a href="<?php echo e(route('dbulanans.index')); ?>" class="btn btn-light fw-bold"
                                    id="btn-detail-dashboard">
                                    <i class="bi bi-info-circle me-1"></i> Detail
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mb-4 mt-4">
                        <?php echo $chart->container(); ?>

                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Menampilkan overlay saat halaman dimuat
            document.querySelector('.loading-overlay').style.display = 'flex';

            // Sembunyikan overlay setelah 2 detik setelah semua konten dimuat
            window.addEventListener('load', function() {
                setTimeout(function() {
                    document.querySelector('.loading-overlay').style.display = 'none';
                }, 1000); // 2 detik (dalam milidetik)
            });
        });
    </script>
    <script src="<?php echo e($chart->cdn()); ?>"></script>
    <?php echo e($chart->script()); ?>


    
    <?php if(session('error')): ?>
        <script>
            alert("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/bidan/index.blade.php ENDPATH**/ ?>