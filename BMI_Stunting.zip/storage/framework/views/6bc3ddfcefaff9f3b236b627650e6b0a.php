<?php $__env->startSection('content'); ?>
    <div class="loading-overlay">
        <div class="spinner-container">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <label>Loading</label>
        </div>
    </div>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="home-section mb-5">
        <div class="container mt-3 pt-3">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 col-md-7 col-12 mb-4">
                    <div class="card shadow">
                        <div class="card-header" id="calc-stunting">
                            <h1 class="card-title fs-3 fw-bold" id="examplecardLabel">Edit Data Bulanan Anak</h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('dbulanans.update', $dbulanans->id)); ?>" method="POST"
                                enctype="multipart/form-dbulanans">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?> <!-- Use the PUT method for editing -->

                                <h3 class="text-center"><?php echo e($dbulanans->danaks->nama_anak); ?></h3>
                                <h6 class="mb-4 text-center"><?php echo e($dbulanans->created_at); ?></h6>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-floating mb-3 d-none">
                                            <input type="text" class="form-control " id="umur_periksa"
                                                name="umur_periksa" placeholder="Masukkan Umur"
                                                value="<?php echo e($dbulanans->umur_periksa); ?>" required readonly>
                                            <label for="floatingInput" class="fw-bold">Umur:</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control" id="st_anak" name="st_anak"
                                                placeholder="Status Anak" value="<?php echo e($dbulanans->st_anak); ?>" required
                                                readonly
                                                style="color: <?php echo e($dbulanans->st_anak === 'Normal' ? 'mediumseagreen' : ($dbulanans->st_anak === 'Gizi Buruk' ? 'red' : ($dbulanans->st_anak === 'Gizi Kurang' ? 'darkorange' : ($dbulanans->st_anak === 'Kelebihan Berat Badan' ? 'darkblue' : 'black')))); ?>">

                                            <label for="st_anak" class="fw-bold">Status Anak:</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <select class="form-select" id="floatingSelectGrid" name="c_ukur"
                                                id="c_ukur">
                                                <option class="d-none" selected value="<?php echo e($dbulanans->c_ukur); ?>">
                                                    <?php echo e($dbulanans->c_ukur); ?>

                                                </option>
                                                <option value="Berdiri">Berdiri</option>
                                                <option value="Telentang">Telentang</option>
                                            </select>
                                            <label for="floatingSelectGrid" class="fw-bold">Cara Ukur</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control border border-0z   " id="bb_anak"
                                                name="bb_anak" placeholder="Masukkan Berat Badan (KG)"
                                                value="<?php echo e($dbulanans->bb_anak); ?>" required>
                                            <label for="bb_anak" class="fw-bold">Berat Badan (KG):</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control border border-0z   " id="tb_anak"
                                                name="tb_anak" placeholder="Masukkan Tinggi Badan (CM)"
                                                value="<?php echo e($dbulanans->tb_anak); ?>" required>
                                            <label for="tb_anak" class="fw-bold">Tinggi Badan (CM):</label>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control border border-0z " id="lk_anak"
                                                name="lk_anak" placeholder="Masukkan Lingkar Kepala (CM)"
                                                value="<?php echo e($dbulanans->lk_anak); ?>" required>
                                            <label for="floatingInput" class="fw-bold">Lingkar Kepala (CM):</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control border border-0z " id="ll_anak"
                                                name="ll_anak" placeholder="Masukkan Lingkar Lengan (CM)"
                                                value="<?php echo e($dbulanans->ll_anak); ?>" required>
                                            <label for="floatingInput" class="fw-bold">Lingkar Lengan (CM):</label>
                                        </div>
                                    </div>
                                </div>


                                
                                <div class="d-none">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control d-none" id="danaks_id" name="danaks_id"
                                            placeholder="Masukkan Nama Anak" value="<?php echo e($dbulanans->danaks->id); ?>" required>
                                        <label for="floatingInput" class="fw-bold">Nama Anak:</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="created_at" name="created_at"
                                            placeholder="Masukkan created" value="<?php echo e($dbulanans->created_at); ?>" required>
                                        <label for="floatingInput" class="fw-bold">created:</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control border border-0z " id="updated_at"
                                            name="updated_at" placeholder="Masukkan updated"
                                            value="<?php echo e($dbulanans->updated_at); ?>" required>
                                        <label for="floatingInput" class="fw-bold">updated:</label>
                                    </div>
                                </div>

                                
                                <input type="text" id="umur_tahun" name="umur_tahun" class="d-none" required
                                    placeholder="umur_tahun" value="<?php echo e($dbulanans->umur_tahun); ?>">
                                <input type="text" id="umur_bulan" name="umur_bulan" class="d-none" required
                                    placeholder="umur_bulan" value="<?php echo e($dbulanans->umur_bulan); ?>">
                                <input type="text" id="data-jk" name="data-jk" class="d-none" required
                                    placeholder="data-jk" value="<?php echo e($dbulanans->danaks->jk); ?>">


                                <hr>
                                <div class="row d-flex justify-content-center pb-4">
                                    <div class="col-md-4 col-4 d-grid">
                                        <a href="<?php echo e(route('dbulanans.index')); ?>" id="batal"
                                            class="btn btn-danger shadow" dposyandus-bs-dismiss="card">Batal</a>
                                    </div>
                                    <div class="col-md-4 col-3 d-grid">
                                        <button class="btn btn-success shadow">Edit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <script>
            // Loading
            document.addEventListener("DOMContentLoaded", function() {
                // Menampilkan overlay saat halaman dimuat
                document.querySelector('.loading-overlay').style.display = 'flex';

                // Sembunyikan overlay setelah 2 detik setelah semua konten dimuat
                window.addEventListener('load', function() {
                    setTimeout(function() {
                        document.querySelector('.loading-overlay').style.display = 'none';
                    }, 1000); // 2 detik (dalam milidetik)
                });
            });
            document.addEventListener("DOMContentLoaded", function() {
                // Mendapatkan referensi ke elemen input
                let bb_anakInput = document.getElementById('bb_anak');
                let tb_anakInput = document.getElementById('tb_anak');
                let lk_anakInput = document.getElementById('lk_anak');
                let ll_anakInput = document.getElementById('ll_anak');
                let umurInputt = document.getElementById('umur_tahun');
                let st_anakInput = document.getElementById('st_anak');
                let jkValue = document.getElementById('data-jk').value; // Ambil nilai dari elemen

                // Tambahkan event listener ke setiap input untuk memanggil fungsi updateStatusAnak saat ada perubahan
                bb_anakInput.addEventListener('input', updateStatusAnak);
                tb_anakInput.addEventListener('input', updateStatusAnak);
                lk_anakInput.addEventListener('input', updateStatusAnak);
                ll_anakInput.addEventListener('input', updateStatusAnak);

                function updateStatusAnak() {
                    let bb_anakValue = parseFloat(bb_anakInput.value);
                    let tb_anakValue = parseFloat(tb_anakInput.value);
                    let lk_anakValue = parseFloat(lk_anakInput.value);
                    let ll_anakValue = parseFloat(ll_anakInput.value);
                    let ut_anakValue = parseFloat(umurInputt.value);

                    if (!isNaN(bb_anakValue) && !isNaN(tb_anakValue) && !isNaN(lk_anakValue) && !isNaN(ll_anakValue)) {
                        let tinggiMeter = tb_anakValue / 100;
                        let imt = bb_anakValue / (tinggiMeter * tinggiMeter);

                        // Logika perhitungan status anak berdasarkan usia dan jenis kelamin
                        if (ut_anakValue < 5) {
                            if (jkValue === 'L') {
                                if (imt < 16) {
                                    st_anakInput.value = "Gizi Buruk";
                                } else if (imt >= 16 && imt < 17) {
                                    st_anakInput.value = 'Gizi Kurang';
                                } else if (imt >= 17 && imt < 18) {
                                    st_anakInput.value = 'Normal';
                                } else {
                                    st_anakInput.value = 'Kelebihan Berat Badan';
                                }
                            } else if (jkValue === 'P') {
                                if (imt < 16) {
                                    st_anakInput.value = "Gizi Buruk";
                                } else if (imt >= 16 && imt < 17) {
                                    st_anakInput.value = 'Gizi Kurang';
                                } else if (imt >= 17 && imt < 18) {
                                    st_anakInput.value = 'Normal';
                                } else {
                                    st_anakInput.value = 'Kelebihan Berat Badan';
                                }
                            }
                        } else {
                            if (imt < 10) {
                                st_anakInput.value = 'Gizi Kurang';
                            } else if (imt >= 10 && imt < 25) {
                                st_anakInput.value = 'Normal';
                            } else {
                                st_anakInput.value = 'Kelebihan Berat Badan';
                            }
                        }

                        // Set warna teks berdasarkan nilai status anak yang baru
                        switch (st_anakInput.value) {
                            case 'Normal':
                                st_anakInput.style.color = 'mediumseagreen';
                                break;
                            case 'Gizi Buruk':
                                st_anakInput.style.color = 'red';
                                break;
                            case 'Gizi Kurang':
                                st_anakInput.style.color = 'darkorange';
                                break;
                            case 'Kelebihan Berat Badan':
                                st_anakInput.style.color = 'darkblue';
                                break;
                            default:
                                st_anakInput.style.color = 'black';
                                break;
                        }
                    } else {
                        st_anakInput.value = '- Inputan Tidak Valid';
                    }
                }
            });
        </script>


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/editbulanan.blade.php ENDPATH**/ ?>