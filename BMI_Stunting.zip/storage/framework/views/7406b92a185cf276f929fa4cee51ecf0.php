<?php $__currentLoopData = $dantrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dantrian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center">
            <?php echo e($nomor++); ?>.
        </td>
        <td>
            <?php echo e($dantrian->n_antrian); ?>

        </td>
        <td>
            <?php echo e($dantrian->t_posyandu); ?>

        </td>
        <td>
            <?php echo $__env->make('actions.actionantrian2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/kader/ajaxtb.blade.php ENDPATH**/ ?>