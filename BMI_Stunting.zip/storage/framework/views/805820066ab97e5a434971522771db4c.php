<div class="modal-header">
    <h1 class="modal-title fs-3 fw-bold" id="exampleModalLabel">Tambah Antrian</h1>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <form action="<?php echo e(route('antrians.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="mb-3">
                    <label for="n_antrian" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="n_antrian" name="n_antrian"
                        placeholder="Massukkan Nama" required>
                </div>
                <div class="mb-3">
                    <label for="n_antrian" class="form-label">Pilih Posyandu</label>
                    <select class="form-select mb-3 border border-dark-subtle" aria-label="Default select example"
                        name="t_posyandu" id="t_posyandu" required>
                        <option disabled value="" <?php echo e(old('t_posyandu') ? '' : 'selected'); ?>>Silahkan Pilih
                        </option>
                        <?php $__currentLoopData = $dposyandu->sortBy('nama_posyandu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->nama_posyandu); ?>" selected
                                <?php echo e(old('t_posyandu') === $data->nama_posyandu ? 'selected' : ''); ?>>
                                <?php echo e($data->nama_posyandu); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>





        <!-- Button -->
        <hr>
        <div class="row d-flex justify-content-center">
            <div class="col-md-3 col-3 d-grid">
                <a id="batal" class="btn btn-danger shadow" data-bs-dismiss="modal">Batal</a>
            </div>
            <div class="col-md-3 col-3 d-grid">
                <button class="btn btn-success shadow">Simpan</button>
            </div>
        </div>
    </form>

</div>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/tambahantrian2.blade.php ENDPATH**/ ?>