<div class="d-flex">
    <a href="<?php echo e(route('ekms.show', ['ekm' => $dbulanan->danaks_id])); ?>"
        class="btn btn-warning btn-sm me-2 shadow">
        <i class="bi bi-file-earmark-bar-graph"></i>
    </a>
</div>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/actionekms.blade.php ENDPATH**/ ?>