<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex flex row">
            <p class="fs-3 fw-bold ">
                Posyandu <?php echo e($nama_posyandu); ?>

            </p>
            <div class="d-flex justify-content-start">
                <a class="btn d-flex me-sm-3 me-2 mb-3 mb-md-0" id="btn-tambah" href="<?php echo e(route('pposyandu')); ?>">
                    <i class="bi bi-chevron-left me-sm-2 me-0"></i>
                    <label class="d-sm-block d-none">Kembali</label>
                </a>
            </div>
            <div class="d-flex flex-row justify-content-end mb-3">
                <a class="btn btn-logreg btn d-flex me-sm-3 me-2 mb-3 mb-md-0" href="javascript:location.reload(true);">
                    <i class="bi bi-arrow-clockwise me-sm-2 me-0"></i>
                    <label class="d-sm-block d-none">Muat Ulang</label>
                </a>
                <button type="button" class="btn d-flex shadow me-sm-3 me-2 mb-3 mb-md-0" data-bs-toggle="modal"
                    id="btn-tambah" data-bs-target="#exampleModal2">
                    <i class="bi bi-list-task me-sm-2 me-0"></i><label class="d-sm-block d-none">Tambah Antrian</label>
                </button>
                <button type="button" class="btn d-flex shadow me-sm-3 me-2 mb-3 mb-md-0 " data-bs-toggle="modal"
                    id="btn-tambah" data-bs-target="#exampleModal">
                    <i class="bi bi-person-fill-add me-sm-2 me-0"></i><label class="d-sm-block d-none">Data Anak</label>
                </button>
            </div>
        </div>


        <!-- Modal Anak-->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <?php echo $__env->make('actions.tambahanak2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModal2Label" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <?php echo $__env->make('actions.tambahantrian2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>


        <div class="row justify-content-center">
            <div class="col-12 col-lg-6 mb-4">
                <div class="mt-2 px-1">
                    <table id="tabel_antrian" class="table table-bordered shadow" style="width:100%; display: block;">
                        <thead class="table-warning">
                            <tr>
                                <th id="th">Urutan</th>
                                <th id="th" class="w-100">Nama</th>
                                <th id="th">Opsi</th>
                            </tr>
                        </thead>
                        <tbody id="tabel-antrian-body">
                            <?php $nomor = 1; ?>
                            <?php $__currentLoopData = $dantrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dantrian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e($nomor++); ?>.
                                    </td>
                                    <td>
                                        <?php echo e($dantrian->n_antrian); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo $__env->make('actions.actionantrian2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-12 col-lg-6 mb-5 d-flex">
                <?php echo $__env->make('actions.kalkulatorkader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="row mt-4">
            <p class="fs-3 fw-bold">
                Tabel Bulanan Posyandu <?php echo e($nama_posyandu); ?>

            </p>
            <div class="col-12 mb-4">
                <div class="mt-2 px-1">
                    <table id="tabel_bulanan" class="table table-bordered shadow datatable" style="width:100%;">
                        <thead class="table-warning">
                            <tr>
                                <th id="th" class="text-center align-middle w-25 ">Nama</th>
                                <th id="th" class="text-center align-middle w-25">Umur</th>
                                <th id="th" class="text-center align-middle w-25">Tanggal
                                    Priksa
                                </th>
                                <th id="th" class="text-center align-middle w-25">
                                    Posyandu
                                </th>
                                <th id="th" class="text-center align-middle">Opsi</th>
                            </tr>
                        </thead>
                        <tbody id="tabel-bulanan-body">
                            <?php $__currentLoopData = $dbulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dbulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($dbulan->danaks->nama_anak); ?>

                                    </td>
                                    <td class="text-center align-middle">
                                        <?php echo e($dbulan->umur_tahun); ?> Tahun <?php echo e($dbulan->umur_bulan); ?> Bulan
                                    </td>
                                    <td class="text-center align-middle">
                                        <?php echo e($dbulan->created_at->format('d-m-Y')); ?>

                                    </td>
                                    <td class="text-center align-middle">
                                        
                                        <?php echo e($dbulan->nama_posyandu); ?>

                                    </td>
                                    <td class="text-center align-middle">
                                        <?php echo $__env->make('actions.actionbulanankader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <?php if(session('error')): ?>
        <script>
            alert("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="module">
        // Tabel Antrian
        $(document).ready(function() {
            var dataTable = new DataTable('#tabel_antrian', {
                pagingType: 'simple',
                responsive: true,
                lengthMenu: [
                    [6, 10],
                    [6, 10]
                ],
                language: {
                    search: "Cari", // Mengganti teks "Search" menjadi "Cari"
                },
            });
            var dataTable = new DataTable('#tabel_bulanan', {
                pagingType: 'simple',
                responsive: true,
                order: [
                    [3, "asc"]
                ],
                lengthMenu: [
                    [25, 50, 100, -1],
                    [25, 50, 100, "All"],
                ],
                language: {
                    search: "Cari", // Mengganti teks "Search" menjadi "Cari"
                },
            });

        });
        $(".datatable").on("click", ".btn-delete", function(e) {
            e.preventDefault();

            var form = $(this).closest("form");

            Swal.fire({
                title: "Apakah Anda Yakin Menghapus Data " + "?",
                text: "Anda tidak akan dapat mengembalikannya!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonClass: "bg-primary",
                confirmButtonText: "Ya, hapus!",
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/kader/index.blade.php ENDPATH**/ ?>