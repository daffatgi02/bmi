<table>
    <thead>
        <tr>
            <th>No</th>
            <th>NIK</th>
            <th>nama_anak</th>
            <th>tgl_lahir</th>
            <th>umur_tahun</th>
            <th>umur_bulan</th>
            <th>jenis_kelamin</th>
            <th>nama_ortu</th>
            <th>nik_ortu</th>
            <th>hp_ortu</th>
            <th>PKM</th>
            <th>KEL</th>
            <th>POSY</th>
            <th>RT</th>
            <th>RW</th>
            <th>ALAMAT</th>
            <th>TANGGALUKUR</th>
            <th>TINGGI</th>
            <th>CARAUKUR</th>
            <th>BERAT</th>
            <th>LILA</th>
            <th>vita</th>
            <th>lingkar_kepala</th>
            <th>asi_bulan_1</th>
            <th>asi_bulan_2</th>
            <th>asi_bulan_3</th>
            <th>asi_bulan_4</th>
            <th>asi_bulan_5</th>
            <th>asi_bulan_6</th>
            <th>pemberian_ke</th>
            <th>sumber_pmt</th>
            <th>pemberian_pusat</th>
            <th>tahun_produksi</th>
            <th>pemberian_daerah</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dbulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dbulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td>&nbsp;<?php echo e($dbulan->danaks->nik_anak); ?></td>
                <td ><?php echo e($dbulan->danaks->nama_anak); ?></td>
                <td><?php echo e($dbulan->danaks->tanggal_lahir); ?></td>
                <td><?php echo e($dbulan->umur_tahun); ?></td>
                <td><?php echo e($dbulan->umur_bulan); ?></td>
                <td><?php echo e($dbulan->danaks->jk); ?></td>
                <td><?php echo e($dbulan->danaks->nama_ortu); ?></td>
                <td >&nbsp;<?php echo e($dbulan->danaks->nik_ortu); ?></td>
                <td>&nbsp;<?php echo e($dbulan->danaks->hp_ortu); ?></td>
                <td><?php echo e($dbulan->danaks->dposyandu->pkm); ?></td>
                <td><?php echo e($dbulan->danaks->dposyandu->kel); ?></td>
                <td><?php echo e($dbulan->danaks->dposyandu->nama_posyandu); ?></td>
                <td><?php echo e($dbulan->danaks->dposyandu->rt); ?></td>
                <td><?php echo e($dbulan->danaks->dposyandu->rw); ?></td>
                <td><?php echo e($dbulan->danaks->dposyandu->lokasi_posyandu); ?></td>
                <td><?php echo e($dbulan->created_at->format('Y-m-d')); ?></td>
                <td><?php echo e($dbulan->tb_anak); ?></td>
                <td><?php echo e($dbulan->c_ukur); ?></td>
                <td><?php echo e($dbulan->bb_anak); ?></td>
                <td><?php echo e($dbulan->ll_anak); ?></td>
                <td></td>
                <td><?php echo e($dbulan->lk_anak); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/bidan/export_bulanan.blade.php ENDPATH**/ ?>