<div class="modal-header">
    <h1 class="modal-title fs-3 fw-bold" id="exampleModalLabel">Tambah Data Anak</h1>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <form action="<?php echo e(route('danaks.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12">
                <h5 class="fw-bold">Informasi Anak</h5>

                <!-- Input NIK Anak -->
                <div class="form-floating mb-3">
                    <input type="text"
                        class="form-control border border-dark-subtle <?php $__errorArgs = ['nik_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="nik_anak" name="nik_anak" placeholder="Masukkan NIK" required maxlength="16"
                        value="<?php echo e(old('nik_anak')); ?>">
                    <label for="nik_anak" class="">NIK Anak:</label>
                    <?php $__errorArgs = ['nik_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Input Nama Anak -->
                <div class="form-floating mb-3">
                    <input type="text"
                        class="form-control border border-dark-subtle <?php $__errorArgs = ['nama_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="nama_anak" name="nama_anak" placeholder="Masukkan Nama Anak" required
                        value="<?php echo e(old('nama_anak')); ?>">
                    <label for="nama_anak" class="">Nama Anak:</label>
                    <?php $__errorArgs = ['nama_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Select Jenis Kelamin -->
                <select class="form-select mb-3 border border-dark-subtle <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    aria-label="Default select example" name="jk" id="jk" required>
                    <option disabled value="" <?php echo e(old('jk') ? '' : 'selected'); ?>>Pilih Jenis Kelamin</option>
                    <option value="L" <?php echo e(old('jk') === 'L' ? 'selected' : ''); ?>>Laki-Laki</option>
                    <option value="P" <?php echo e(old('jk') === 'P' ? 'selected' : ''); ?>>Wanita</option>
                </select>
                <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Input Tanggal Lahir -->
                <div class="form mb-3">
                    <h6 class="">Tanggal Lahir:</h6>
                    <input type="date"
                        class="form-control border border-dark-subtle <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="tanggal_anak" name="tanggal_lahir" required value="<?php echo e(old('tanggal_lahir')); ?>">
                    <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Select Posyandu -->
                <select class="form-select mb-3 border border-dark-subtle <?php $__errorArgs = ['dposyandu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    aria-label="Default select example" name="dposyandu_id" id="dposyandu_id" required>
                    <option disabled value="" <?php echo e(old('dposyandu_id') ? '' : 'selected'); ?>>Pilih Posyandu</option>
                    <?php $__currentLoopData = $dposyandu->sortBy('nama_posyandu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"
                            <?php echo e(old('dposyandu_id') === $data->nama_posyandu ? 'selected' : ''); ?>>
                            <?php echo e($data->nama_posyandu); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <?php $__errorArgs = ['dposyandu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-lg-6 col-md-12 col-12">
                <!-- Informasi Tambahan -->
                <h5 class="fw-bold">Informasi Orang Tua</h5>

                <!-- Input NIK Anak -->
                <div class="form-floating mb-3">
                    <input type="text"
                        class="form-control border border-dark-subtle <?php $__errorArgs = ['nik_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="nik_ortu" name="nik_ortu" placeholder="Masukkan NIK" required maxlength="16"
                        value="<?php echo e(old('nik_ortu')); ?>">
                    <label for="nik_ortu" class="">NIK Orang tua:</label>
                    <?php $__errorArgs = ['nik_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Input Nama Ortu -->
                <div class="form-floating mb-3">
                    <input type="text"
                        class="form-control border border-dark-subtle <?php $__errorArgs = ['nama_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="nama_ortu" name="nama_ortu" placeholder="Masukkan Nama Ortu" required
                        value="<?php echo e(old('nama_ortu')); ?>">
                    <label for="nama_ortu" class="">Nama Orang Tua:</label>
                    <?php $__errorArgs = ['nama_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Input Nomor WA -->
                <div class="form-floating mb-3">
                    <input type="text"
                        class="form-control border border-dark-subtle <?php $__errorArgs = ['hp_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="hp_ortu" name="hp_ortu" placeholder="Masukkan Nomor HP" required maxlength="13"
                        value="<?php echo e(old('hp_ortu')); ?>">
                    <label for="hp_ortu" class="">No WA:</label>
                    <?php $__errorArgs = ['hp_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>




        <!-- Button -->
        <hr>
        <div class="row d-flex justify-content-center">
            <div class="col-md-3 col-3 d-grid">
                <a id="batal" class="btn btn-danger shadow" data-bs-dismiss="modal">Batal</a>
            </div>
            <div class="col-md-3 col-3 d-grid">
                <button class="btn btn-success shadow">Simpan</button>
            </div>
        </div>
    </form>

</div>


<script>
    // Mendapatkan elemen-elemen yang diperlukan
    const radioBulan = document.getElementById("c_bulan");
    const radioTahun = document.getElementById("c_tahun");
    const inputUmur = document.getElementById("umur");

    // Mendengarkan perubahan pada radio button
    radioBulan.addEventListener("change", function() {
        if (radioBulan.checked) {
            // Jika radio "Bulan" dipilih, pastikan hanya satu spasi yang ada di antara angka umur dan kata "Bulan"
            inputUmur.value = inputUmur.value.replace(" Tahun", "").replace(" Bulan", "") + " Bulan";
        }
    });

    radioTahun.addEventListener("change", function() {
        if (radioTahun.checked) {
            // Jika radio "Tahun" dipilih, pastikan hanya satu spasi yang ada di antara angka umur dan kata "Tahun"
            inputUmur.value = inputUmur.value.replace(" Bulan", "").replace(" Tahun", "") + " Tahun";
        }
    });
</script>
<?php /**PATH D:\Job\Project\BMI_Stunting\resources\views/actions/tambahanak.blade.php ENDPATH**/ ?>